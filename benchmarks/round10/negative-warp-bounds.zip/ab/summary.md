# Per-warp Gaussian backward bounds: balanced A/B

Measured source `8438c04614bab6611aa8b555ef8f86ed961b0483`. Ten paired rounds, order reversed each round. All other code paths are unchanged in the same binary. GPU event timing below isolates the synthetic backward launch; real-scene rows use synchronized wall time. The real scene has 139410 Gaussians. Host-load observations are in hostload.log.

| Workload | Metric | Tile bound: median [min,max] | Warp bound: median [min,max] | Change | Lower pairs |
|---|---|---|---|---|---|
| 1024 | backward_median_ms | 27.2565 [26.3702,30.2706] | 28.1663 [26.5162,29.5936] | +3.34% | 3/10 |
| 1024 | cuda_peak_allocated_backward | 232.8652 [232.8652,232.8652] | 232.8652 [232.8652,232.8652] | +0.00% | 0/10 |
| 1024 | cuda_peak_allocated_forward | 129.7222 [129.7222,129.7222] | 129.7222 [129.7222,129.7222] | +0.00% | 0/10 |
| 1024 | cuda_peak_reserved | 308.0000 [308.0000,308.0000] | 308.0000 [308.0000,308.0000] | +0.00% | 0/10 |
| 1024 | forward_backward_median_ms | 41.6302 [39.4937,46.3941] | 42.5867 [40.0937,44.2715] | +2.30% | 5/10 |
| 1024 | forward_median_ms | 13.1334 [12.0919,15.4707] | 13.1240 [11.9661,13.6973] | -0.07% | 6/10 |
| 1024 | process_peak_working_set | 976.1816 [975.9336,977.2773] | 976.2090 [975.9766,976.5039] | +0.00% | 5/10 |
| 1024 | train_median_ms | 69.0359 [66.1830,73.4726] | 69.3546 [67.5206,71.4355] | +0.46% | 5/10 |
| 512 | backward_median_ms | 14.3055 [13.2041,14.8491] | 14.8931 [14.3547,15.5246] | +4.11% | 0/10 |
| 512 | cuda_peak_allocated_backward | 196.5239 [196.5239,196.5239] | 196.5239 [196.5239,196.5239] | +0.00% | 0/10 |
| 512 | cuda_peak_allocated_forward | 100.1484 [100.1484,100.1484] | 100.1484 [100.1484,100.1484] | +0.00% | 0/10 |
| 512 | cuda_peak_reserved | 244.0000 [244.0000,244.0000] | 244.0000 [244.0000,244.0000] | +0.00% | 0/10 |
| 512 | forward_backward_median_ms | 24.7206 [22.3300,25.3323] | 25.6587 [24.4274,27.4795] | +3.79% | 1/10 |
| 512 | forward_median_ms | 9.7371 [8.7611,10.5815] | 10.2758 [9.6195,11.8008] | +5.53% | 3/10 |
| 512 | process_peak_working_set | 965.0918 [964.8438,966.1875] | 965.1191 [964.8867,965.4141] | +0.00% | 5/10 |
| 512 | train_median_ms | 27.7570 [26.3903,28.2912] | 27.7554 [25.0310,29.5363] | -0.01% | 3/10 |
| dense | gpu_ms | 10.1413 [9.4502,10.9732] | 10.6437 [10.0495,11.0300] | +4.95% | 2/10 |
| dense | wall_ms | 10.4689 [9.7977,11.3513] | 11.0385 [10.4247,11.4858] | +5.44% | 2/10 |
| row-groups | gpu_ms | 2.0373 [1.9113,2.1800] | 2.0862 [2.0017,2.1231] | +2.40% | 5/10 |
| row-groups | wall_ms | 2.4226 [2.2211,2.7310] | 2.4723 [2.3607,2.5500] | +2.05% | 6/10 |
| sparse | gpu_ms | 2.3657 [2.2621,2.4594] | 2.2816 [2.2072,2.3183] | -3.55% | 9/10 |
| sparse | wall_ms | 2.7398 [2.5613,2.9865] | 2.6313 [2.5195,2.7027] | -3.96% | 8/10 |

Memory columns are MiB. This branch only records render-phase CUDA peaks, not training VRAM. Working set is cumulative over the complete process. The forward-only measurements are unchanged-path noise controls. Synthetic tile layouts are stress controls, not observed real-scene coverage. Training throughput can be derived as 1000/step_ms; no accuracy or convergence improvement is implied.
