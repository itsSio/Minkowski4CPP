$ErrorActionPreference = 'Stop'
$lab = 'C:\Users\User\Work\mink-lab'
$src = 'C:\Users\User\Work\mink-wt\gauss-cull'
$out = "$lab\results\round10\gaussian"
. "$lab\tools\mink-env.ps1" -Quiet
Set-Location C:\Users\User\Work\mink-build\gauss-cull-cuda
& nvidia-smi --query-gpu=name,driver_version,memory.used,utilization.gpu --format=csv > "$out\baseline-gpu.txt"
& pwsh -NoProfile -File "$lab\results\bridge-ml\r3\hostload.ps1" -Log "$out\baseline-hostload.log" -Tag before -Sec 3
foreach ($pattern in 'row-groups','dense','sparse') {
  & .\gaussian_raster_backward_bench.exe --pattern $pattern --tiles 32 --per-tile 256 --warmup 5 --iterations 30 --output "$out\baseline-$pattern.json" *> "$out\baseline-$pattern.txt"
  if ($LASTEXITCODE) { throw "Baseline $pattern failed: $LASTEXITCODE" }
}
& .\gaussian_render_bench.before-warp-bounds.exe --input "$src\tests\data\test.ply" --counts 0 --sizes 512,1024 --devices cuda --warmup 3 --iterations 10 --train --output "$out\baseline-render.json" *> "$out\baseline-render.txt"
if ($LASTEXITCODE) { throw "Baseline renderer failed: $LASTEXITCODE" }
@{
  completed = (Get-Date -Format o); source = (& git -C $src rev-parse HEAD).Trim(); status = 'passed'
  raster_binary_sha256 = (Get-FileHash .\gaussian_raster_backward_bench.exe -Algorithm SHA256).Hash
  render_binary_sha256 = (Get-FileHash .\gaussian_render_bench.before-warp-bounds.exe -Algorithm SHA256).Hash
  input_sha256 = (Get-FileHash "$src\tests\data\test.ply" -Algorithm SHA256).Hash
} | ConvertTo-Json | Set-Content "$out\baseline-receipt.json"
& pwsh -NoProfile -File "$lab\results\bridge-ml\r3\hostload.ps1" -Log "$out\baseline-hostload.log" -Tag after -Sec 3
