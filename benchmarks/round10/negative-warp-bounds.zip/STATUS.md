# Round 10 Gaussian raster investigation

Owner: gaussian_cuda. Root approved continued implementation, not only evidence audits.
Branch: perf/gaussian-backward-warp-bounds in C:/Users/User/Work/mink-wt/gauss-cull.
Existing build dirs gauss-cull-cuda and gauss-cull-cpu. Root integration is untouched.

Baseline commit dbead49 adds a direct raster benchmark only, based on gather PR53
229f04d. Baseline native build passed; locked baseline profiling completed at 20:05:45.
Files baseline-*.json, baseline-receipt.json and baseline-hostload.log are raw evidence.
Old gaussian_tests/render_bench binaries are preserved as *.before-warp-bounds.exe.

Hypothesis: each warp can skip reverse raster list entries beyond its own maximum
forward last_index. Existing code uses the maximum across all 256 tile threads.
Prior real-scene Kineto: raster backward about 2.18ms/step. New synthetic census:
row-groups 2,031,616 tile-bound scans vs 1,114,112 warp-bound scans (-45.2% potential);
sparse 2,097,152 vs 524,288 (-75% potential); dense identical 2,097,152.
Baseline GPU event medians were about 2.06ms row-groups, 2.34ms sparse, 9.88ms dense.
These are isolated synthetic backward kernels, not end-to-end improvement claims.

Candidate uncommitted: template bool WarpBounds in gaussian_raster_cuda.cu,
five XOR shuffles to compute per-warp max; shared staging/barriers unchanged.
Internal hook cuda_raster_backward_warp_bounds(), --warp-bounds on direct and
render benchmark. Three new tests cover batch boundaries 0/1/31/255/256/257/513,
partial edge tiles, nondefault stream, zero upstream loss and ten finite differences.
Candidate native CUDA build PID33768 started20:08; logs candidate-build.log/.err.

Next: inspect build; run focused tests under GPU lock; if correct, same-binary
balanced A/B under bench lock on synthetic controls and real PLY. Reject if no
meaningful end-to-end gain or significant dense regression. Then CPU+CUDA full suites,
sanitizers, report with raw data, commit and separate stacked PR plus technical comment.
Native evidence is supplementary; root/environment teammate pursuing actual Docker.
Use local locks for every build/GPU operation. No service changes, no host dependencies.

20:12 update: candidate8438c04 built successfully (candidate-build2.log; initial failure was CHECK_ALLCLOSE using absent torch::allclose, fixed to at::allclose). Focused3/3 pass, including10 finite differences; old/new direct differences <=4.77e-7 in fixtures. after-build2.ps1 PID10884 now awaiting exclusive benchmarklock behind adaptive CUDA compile. Do not relaunch. Once ab/receipt.json passed, run summarize.py and inspect real-scene benefit/dense control.

20:17 REJECTED8438c04 after10pairedrounds: denseGPU+4.95%, row-groupGPU+2.40%, sparseGPU-3.55%; real512backward+4.11%(0/10better), trainingflat. Correctness3/3passesbutnojustifiedperformancegain. Branchandrawpreserved; gauss-cullswitchestoperf/gaussian-backward-parallel-atomicsfornextcandidate. See siblinggaussian-atomics/STATUS.md.
