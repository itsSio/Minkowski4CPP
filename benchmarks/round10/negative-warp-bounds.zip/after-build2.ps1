$ErrorActionPreference='Stop'
$lab='C:\Users\User\Work\mink-lab'
$out="$lab\results\round10\gaussian"
while (Get-Process -Id 1128 -ErrorAction SilentlyContinue) {Start-Sleep -Seconds 5}
if (-not (Select-String -LiteralPath "$out\candidate-build2.log" -Pattern 'mink-build: exit 0' -Quiet)) {throw 'Candidate build did not pass'}
& pwsh -NoProfile -File "$lab\tools\with-lock.ps1" -Kind gpu -Who gaussian-warp-tests -Command "pwsh -NoProfile -File $out\validate-focused.ps1"
if ($LASTEXITCODE) {throw 'Focused tests failed'}
& pwsh -NoProfile -File "$lab\tools\with-lock.ps1" -Kind bench -Who gaussian-warp-ab -Command "pwsh -NoProfile -File $out\ab.ps1"
if ($LASTEXITCODE) {throw 'A/B failed'}
